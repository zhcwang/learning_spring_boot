package learning.java.spring.springboot.springbootpropelling;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootPropellingApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootPropellingApplication.class, args);
	}
}
